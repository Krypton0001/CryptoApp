#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    QIcon appIcon(":/Icons/Icons/crypt.icon");
    w.setWindowIcon(appIcon);
    w.setWindowTitle("Cryptograp");
    w.show();

    return a.exec();
}
