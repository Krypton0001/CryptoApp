#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public slots:
    void counter();
    //---------Hill--------Crypt------
    int deter2(int a[2][2]);
    int deter3(int a[3][3]);
    void translateInput();
    void translateOutput();
    //--------Vigenere----------------

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    int search(QString);
    int evklida(int, int, int);
    QString *alphabet = new QString();

private slots:
    void on_envrypt_button_clicked();
    void on_clear_button_clicked();
    void on_decrypt_button_clicked();
    void check_enter(QKeyEvent *e);

    void on_encryptButton_clicked();

    void on_decryptButton_clicked();
    void muntiplication();
    void demuntiplication();

    void on_encryptCleatButton_clicked();

    void on_decryptClearButton_clicked();

    void on_encryptVigenere_clicked();

    void on_decryptVigenere_clicked();

    void on_encryptPermutation_clicked();

private:
    Ui::MainWindow *ui;
    //---------Hill--------Crypt------
    QString *key = new QString;
    QString *phrase = new QString;
    QString *encrypt = new QString;
    //--------Vigenere----------------
};

#endif // MAINWINDOW_H
