#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QKeyEvent>
#include <QDebug>
#include <cmath>
#include <QTableView>
#include <QStandardItem>
#include <QStandardItemModel>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->lcdNumber->display(ui->lineEdit_2->text().size());
    connect(ui->lineEdit_2, SIGNAL(textChanged(QString)), this, SLOT(counter()));
    ui->lineEdit_2->setText("abcdefghijklmnopqrstuvwxyz1234567890 ");
    (*alphabet) = ui->lineEdit_2->text();
//----Encrypt----Hill----
    translateInput();
    translateOutput();
    connect(ui->encryptLineKey, SIGNAL(textChanged(QString)), this, SLOT(translateInput()));
    connect(ui->decryptLineKey, SIGNAL(textChanged(QString)), this, SLOT(translateOutput()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::counter()
{
    int alphabet_size = ui->lineEdit_2->text().size();
    (*alphabet) = ui->lineEdit_2->text();
    ui->lcdNumber->display(alphabet_size);
    ui->inpunKey_box->setMaximum(ui->lineEdit_2->text().size() - 1);
    ui->outputKey_box->setMaximum(ui->lineEdit_2->text().size() - 1);
    ui->inputNum->setMaximum(ui->lineEdit_2->text().size() - 1);
    ui->outputNum->setMaximum(ui->lineEdit_2->text().size() - 1);
}

int MainWindow::search(QString a)
{
    int i = 0;
    while ((*alphabet).at(i) != a.at(0))
    {
        if(i+1 < ((*alphabet).size()))
            i++;
        else
            return -1;
    }
    return i;
}

int MainWindow::evklida(int a, int b, int c)
{
    int result[4];
    int bb = b, xx = 1, x = 0, yy = 1, y = 0, zz = 0, z = 0, q = 0, r = 0;
    while(b > 0)
    {
        q = a / b;
        r = a % b;
        zz = xx - q * x;
        z = yy - q * y;
        a = b;
        b = r;
        xx = x;
        x = zz;
        yy = y;
        y = z;
    }
    result[0] = (zz % bb);
    result[1] = xx;
    result[2] = yy;
    result[3] = b;
    if(c == 0)
        return result[0];
    else
    {
        if(c == 1)
            return result[1];
        else {
            if(c == 2){
                return result[2];
            }
            else {
                return result[3];
            }
        }
    }
}

int MainWindow::deter2(int a[2][2])
{
    return (a[0][0] * a[1][1] - a[0][1] * a[1][0]);
}

int MainWindow::deter3(int a[3][3])
{
    return (a[0][0] * a[1][1] * a[2][2] + a[1][0] * a[2][1] * a[0][2] + a[0][1] * a[1][2] * a[2][0]
          - a[2][0] * a[1][1] * a[0][2] - a[0][0] * a[2][1] * a[1][2] - a[1][0] * a[0][1] * a[2][2]);
}

void MainWindow::translateInput()
{
    QStandardItemModel *model = new QStandardItemModel;
    QString temp = ui->encryptLineKey->text();
    while (temp.size() != 9)
    {
        temp += " ";
    }
    int tmp[3][3];
    for(int i=0; i<9; i++)
    {
         QStandardItem *item;
         int znc = search(temp.at(i));
         tmp[i/3][i%3] = znc;
         item = new QStandardItem(QString::number(znc, 10));
         model->setItem(i/3,i%3, item);
    }
    ui->encryptMatrix->setModel(model);
    ui->encryptMatrix->resizeRowsToContents();
    ui->encryptMatrix->resizeColumnsToContents();
}

void MainWindow::translateOutput()
{
    QStandardItemModel *model = new QStandardItemModel;
    QString temp = ui->encryptLineKey->text();
    while (temp.size() != 9)
    {
        temp += " ";
    }
    int tmp[3][3];
    for(int i=0; i<9; i++)
    {
         QStandardItem *item;
         int znc = search(temp.at(i));
         tmp[i/3][i%3] = znc;
         item = new QStandardItem(QString::number(znc, 10));
         model->setItem(i/3,i%3, item);
    }
    ui->decryptMatrix->setModel(model);
    ui->decryptMatrix->resizeRowsToContents();
    ui->decryptMatrix->resizeColumnsToContents();
}

void MainWindow::on_envrypt_button_clicked()
{
    //QMessageBox::information(this, "Info","Hello world!!!");

    int key_one = ui->inpunKey_box->text().toInt();
    int key_two = ui->inputNum->text().toInt();
    QString inMessage = ui->inMessage_line->text();
    QString out;
    ui->outputKey_box->setValue(key_one);
    ui->outputNum->setValue(key_two);
    int j;

    if(key_one <= 0 || key_two <= 0)
    {
        QMessageBox::warning(this, "Warning","You did not enter keys !!!");
    }
    else if (inMessage == "")
    {
         QMessageBox::warning(this, "Warning","You did not enter message !!!");
    }
    else
    {

        for(int i=0;i<inMessage.size();i++)
        {
            j = search(inMessage.at(i));
            if(j == -1)
                out += inMessage.at(i);
            else
            {
                out += (*alphabet).at((key_one * j + key_two) % ((*alphabet).size()));
                ui->outMessage_lable->setText(out);
            }
        }
        ui->outMessage_lable->setText(out);
    }
    ui->inMessage_line->clear();
}

void MainWindow::on_decrypt_button_clicked()
{
    int evklid = evklida(ui->outputKey_box->text().toInt(), (*alphabet).size(), 1);
    int keyNum = ui->outputNum->text().toInt();
    int j;
    QString input = ui->outMessage_lable->text();
    QString out_message;
    for(int i=0; i<input.size(); i++)
    {
        j = search(input.at(i));
        if(j == -1)
        {
            out_message += input.at(i);
        }
        else
        {
            int p = (evklid * (j - keyNum)) % (*alphabet).size();
            if(p < 0)
            {
                p += (*alphabet).size();
            }
            out_message += (*alphabet).at(p);
        }
    }
    ui->inMessage_line->clear();
    ui->inMessage_line->setText(out_message);
    ui->outMessage_lable->clear();
}

void MainWindow::check_enter(QKeyEvent* e)
{
    if(e->key() == Qt::Key_Enter || e->key() == Qt::Key_Return)
    {
        QMessageBox::information(this, "Info","You clicked ENTER!!!");
    }
}

void MainWindow::on_clear_button_clicked()
{
    ui->inputNum->clear();
    ui->inpunKey_box->clear();
    ui->inMessage_line->clear();
    ui->outputNum->clear();
    ui->outputKey_box->clear();
    ui->outMessage_lable->clear();
}

/*------Enryption-----methot-----Hill------*/

void MainWindow::muntiplication()
{
    int tabKey[3][3]; // Table with position symbol from key
    for (int i = 0;i < 9; i++)
    {
        tabKey[i/3][i%3] = search((*key).at(i));
    }
    int tabPhrase[((*phrase).size()/3)][3];
    for (int i = 0;i < (*phrase).size(); i++)
    {
        tabPhrase[i/3][i%3] = search((*phrase).at(i));
    }
    int alphabetSize = (*alphabet).size();
    QString encryptText;
    for(int i=0;i<((*phrase).size()/3);i++)
    {
        for(int j = 0; j < 3; j++)
        {
            int rez = 0;
            for(int k = 0; k < 3; k++)
            {
                rez += tabKey[j][k] * tabPhrase[i][k];
            }
            encryptText += (*alphabet).at(rez % alphabetSize);
        }
    }
    *encrypt = encryptText;
}

/*-----Decrypton----methot-----Algroithm----Hill-----*/

void MainWindow::demuntiplication()
{
    int tabKey[3][3]; // Table with position symbol from key
    for (int i = 0;i < 9; i++)
    {
        tabKey[i/3][i%3] = search((*key).at(i));
    }
    int tabPhrase[((*phrase).size()/3)][3];
    for (int i = 0;i < (*phrase).size(); i++)
    {
        tabPhrase[i/3][i%3] = search((*phrase).at(i));
    }
    int oper = deter3(tabKey);
    int x = evklida(oper, (*alphabet).size(), 1);

    if(oper > 0)
    {
        if(x < 0)
            x = x + (*alphabet).size();
    }
    else
    {
        if(x < 0)
            x = abs(x);
    }

    int reverseKey[3][3];
    for(int i=0; i < 3; i++)
    {
        for(int j = 0; j < 3; j++)
        {
            int tmp[2][2], str = 0, ssl = 0;
            for(int ii = 0 ; ii < 3; ii++)
            {
                if(ii != i)
                {
                    for (int jj = 0; jj < 3; jj++)
                    {
                        if(jj != j)
                        {
                            tmp[str][ssl] = tabKey[ii][jj];
                            ssl++;
                        }
                    }
                    str++;
                    ssl = 0;
                }
            }
            reverseKey[j][i] = int(pow((-1),(i+j)))*(deter2(tmp));
            reverseKey[j][i] = (reverseKey[j][i]*x)%((*alphabet).size());
            while (reverseKey[j][i]<0)
            {
                reverseKey[j][i] += (*alphabet).size();
            }
        }
    }
    int alphabetSize = (*alphabet).size();
    QString encryptText;
    for(int i=0;i<((*phrase).size()/3);i++)
    {
        for(int j = 0; j < 3; j++)
        {
            int rez = 0;
            for(int k = 0; k < 3; k++)
            {
                rez += reverseKey[j][k] * tabPhrase[i][k];
            }
            encryptText += (*alphabet).at(rez % alphabetSize);
        }
    }
    *encrypt = encryptText;
}

void MainWindow::on_encryptButton_clicked()
{
    if(ui->inputMessage->text() == "" || ui->encryptLineKey->text() == "")
    {
        QMessageBox::critical(this, "Critical","You did not enter message or key !!!");
    }
    else
    {
         ui->outputMessage->clear();
         QString tmp = ui->encryptLineKey->text();
         while(tmp.size() != 9)
             tmp += " ";
         *key = tmp;
         tmp = ui->inputMessage->text();
         while(tmp.size()%3 != 0)
             tmp += " ";
         *phrase = tmp;
         muntiplication();
         ui->outputMessage->setText(*encrypt);
         ui->inputMessage->clear();
    }
}

void MainWindow::on_decryptButton_clicked()
{
    if(ui->decryptLineKey->text() == "")
    {
        QMessageBox::critical(this, "Critical","You did not enter message or key !!!");
    }
    else
    {
        ui->inputMessage->clear();
        QString tmp = ui->decryptLineKey->text();
        while(tmp.size() != 9)
            tmp += " ";
        *key = tmp;
        tmp = ui->outputMessage->text();
        while(tmp.size()%3 != 0)
            tmp += " ";
        *phrase = tmp;
        demuntiplication();
        ui->inputMessage->setText(*encrypt);
        ui->outputMessage->clear();
    }
}


void MainWindow::on_encryptCleatButton_clicked()
{
    ui->encryptLineKey->clear();
    ui->inputMessage->clear();
}

void MainWindow::on_decryptClearButton_clicked()
{
    ui->decryptLineKey->clear();
    ui->outputMessage->clear();
}

/*--------Crypt--Vigenere---------*/

void MainWindow::on_encryptVigenere_clicked()
{
    QString sumKey = "", result, alphabetSize = (*alphabet);
    QString inMessage = ui->inputMessageVigenere->text();
    QString inKey = ui->encryptKeyVigenere->text();
    int *inMsg = new int[inMessage.size()];
    int *inKy = new int[inKey.size()];
    if(inMessage == "" || inKey == "")
    {
        QMessageBox::critical(this, "Critical","You did not enter message or key !!!");
    }
    else
    {
        if(inMessage.size() >= inKey.size())
        {
            for(int i=0; i<(inMessage.size() / inKey.size()); i++)
                sumKey += inKey;
            for (int j = 0; j<(inMessage.size() % inKey.size()); j++)
                sumKey += inKey[j];
        }
        else
        {
            for(int i=0; i<inMessage.size(); i++)
                sumKey += inMessage[i];
        }
        for(int i=0; i<inMessage.size(); i++)
        {
            for(int j=0; j<((*alphabet).size()); j++)
            {
                if(inMessage[i] == alphabetSize[j])
                    inMsg[i] = j;
                if(sumKey[i] == alphabetSize[j])
                    inKy[i] = j;
            }
        }
        int e = 0;
        for(int i=0; i<inMessage.size(); i++)
        {
            e = ((inMsg[i] + inKy[i]) % alphabetSize.size());
            result[i] = alphabetSize[e];
        }
        ui->outputMessageVigenere->setText(result);
        ui->inputMessageVigenere->clear();

    }
}

void MainWindow::on_decryptVigenere_clicked()
{
    QString result, alphabetSize = (*alphabet), currentMessage = ui->outputMessageVigenere->text(),
            deKey = ui->decryptKeyVigenere->text();
    int *inMsg = new int[currentMessage.size()];
    int *inKy = new int[deKey.size()];
    int x;
    if(deKey == "")
    {
        QMessageBox::critical(this, "Critical","You did not enter key !!!");
    }
    else
    {
        for(int i=0; i<currentMessage.size(); i++)
        {
            x = ((inMsg[i] - inKy[i]) % alphabetSize.size());

            result [i]= alphabetSize[x];
        }
        ui->inputMessageVigenere->setText(result);
        ui->outputMessageVigenere->clear();
    }
}

/*-----------Crypt--------Permutation--------------------*/

void MainWindow::on_encryptPermutation_clicked()
{
    QString inMessage = ui->inputMessagePermutation->text(); QString inKey = ui->encryptKeyPermutation->text();
    char *input = new char; QString result;
    int *inkey = new int[inKey.size()];
    for (int i=0; i<(inMessage.size() % inKey.size()); i++)
        input += input[i];
    for(int i=0; i<inMessage.size(); i+=inKey.size())
    {
        char *translate = new char[inKey.size()];
        for(int j=0; j<inKey.size(); j++)
            translate[inkey[j] - 1] = input[i + j];
        for(int k=0; k<inKey.size(); k++)
            result += translate[k];
    }
    ui->outputMessagePermutation->setText(result);
}




















